define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_c2a3a1eef3744e4f86f967d5b7dcec46: function AS_Button_c2a3a1eef3744e4f86f967d5b7dcec46(eventobject) {
        var self = this;
        this.scanBarCode();
    },
    AS_Button_c607279a3bd6457481b5fee1194aa22c: function AS_Button_c607279a3bd6457481b5fee1194aa22c(eventobject) {
        var self = this;
        this.btnPopupYesOnclick();
    },
    AS_Button_ab4c740faeb648c7b0517732e3696419: function AS_Button_ab4c740faeb648c7b0517732e3696419(eventobject) {
        var self = this;
        this.btnPopupNoOnclick();
    },
    AS_FlexContainer_f98feb9db512412e91007a367234946f: function AS_FlexContainer_f98feb9db512412e91007a367234946f(eventobject) {
        var self = this;
        this.cancelScanningIOS();
    },
    AS_Form_ceacfa6d9d5349fe8b39bfdc617cc4e5: function AS_Form_ceacfa6d9d5349fe8b39bfdc617cc4e5(eventobject) {
        var self = this;
        this.formPostShow();
    }
});