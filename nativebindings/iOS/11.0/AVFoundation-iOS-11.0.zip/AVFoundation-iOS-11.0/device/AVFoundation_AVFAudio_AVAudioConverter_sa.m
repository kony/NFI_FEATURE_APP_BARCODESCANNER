if (strcmp(type, @encode(AVAudioConverterPrimeInfo)) == 0) {
		AVAudioConverterPrimeInfo argument;
		[invocation getArgument: &argument atIndex: index];
		return [JSValue valueWithAVAudioConverterPrimeInfo: argument inContext: context];
	}