if (strcmp(type, @encode(AUNodeConnection)) == 0) {
		AUNodeConnection argument;
		[invocation getArgument: &argument atIndex: index];
		return [JSValue valueWithAUNodeConnection: argument inContext: context];
	}