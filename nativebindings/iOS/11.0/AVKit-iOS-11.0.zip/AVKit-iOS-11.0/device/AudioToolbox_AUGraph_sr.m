if (strcmp(type, @encode(AUNodeConnection)) == 0) {
		AUNodeConnection returnValue = value.toAUNodeConnection;
		[invocation setReturnValue: &returnValue];
	}